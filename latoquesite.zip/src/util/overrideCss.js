import { css } from '@emotion/react';

export const overrideCss =  css`
  display: block;
  margin: 0 auto;
`;
